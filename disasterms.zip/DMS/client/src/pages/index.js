import Home from './Home';
import Community from './Community';
import { MedicalHome } from './MedicalHome';

export { Home, Community, MedicalHome };